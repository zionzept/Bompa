/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVTextureExpandNormal {

	/**
	 *  Accepted by the &lt;pname&gt; parameters of TexParameteri,
	 *  TexParameteriv, TexParameterf, TexParameterfv, GetTexParameteri,
	 *  and GetTexParameteriv:
	 */
	public static final int GL_TEXTURE_UNSIGNED_REMAP_MODE_NV = 0x888F;

	private NVTextureExpandNormal() {}
}
