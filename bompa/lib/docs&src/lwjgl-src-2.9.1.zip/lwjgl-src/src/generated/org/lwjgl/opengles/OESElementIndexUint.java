/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESElementIndexUint {

	/**
	 * Accepted by the &lt;type&gt; parameter of DrawElements: 
	 */
	public static final int GL_UNSIGNED_INT = 0x1405;

	private OESElementIndexUint() {}
}
