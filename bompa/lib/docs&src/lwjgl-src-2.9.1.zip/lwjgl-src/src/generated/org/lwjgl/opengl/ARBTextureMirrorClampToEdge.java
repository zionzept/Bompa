/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureMirrorClampToEdge {

	/**
	 *  Accepted by the &lt;param&gt; parameter of TexParameter{if}, SamplerParameter{if}
	 *  and SamplerParameter{if}v, and by the &lt;params&gt; parameter of
	 *  TexParameter{if}v, TexParameterI{i ui}v and SamplerParameterI{i ui}v when
	 *  their &lt;pname&gt; parameter is TEXTURE_WRAP_S, TEXTURE_WRAP_T, or
	 *  TEXTURE_WRAP_R:
	 */
	public static final int GL_MIRROR_CLAMP_TO_EDGE = 0x8743;

	private ARBTextureMirrorClampToEdge() {}
}
