/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESDepth24 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorageOES: 
	 */
	public static final int GL_DEPTH_COMPONENT24_OES = 0x81A6;

	private OESDepth24() {}
}
