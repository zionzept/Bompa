/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRImage2DFromBuffer {

	/**
	 * cl_device_info 
	 */
	public static final int CL_DEVICE_IMAGE_PITCH_ALIGNMENT = 0x104A,
		CL_DEVICE_IMAGE_BASE_ADDRESS_ALIGNMENT = 0x104B;

	private KHRImage2DFromBuffer() {}
}
