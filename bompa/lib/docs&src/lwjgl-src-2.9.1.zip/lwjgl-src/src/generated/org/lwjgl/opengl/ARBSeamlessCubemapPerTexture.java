/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBSeamlessCubemapPerTexture {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameter{if},
	 *  TexParameter{if}v, GetTexParameter{if}v, SamplerParameter{if},
	 *  SamplerParameter{if}v, and GetSamplerParameter{if}v:
	 */
	public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 0x884F;

	private ARBSeamlessCubemapPerTexture() {}
}
