/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVShaderBufferStore {

	/**
	 * Accepted by the &lt;barriers&gt; parameter of MemoryBarrierNV: 
	 */
	public static final int GL_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV = 0x10;

	/**
	 * Accepted by the &lt;access&gt; parameter of MakeBufferResidentNV: 
	 */
	public static final int GL_READ_WRITE = 0x88BA,
		GL_WRITE_ONLY = 0x88B9;

	private NVShaderBufferStore() {}
}
